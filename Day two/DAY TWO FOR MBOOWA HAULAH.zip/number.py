
#integers as numbers
a=1
b=356777
c=-775
print(type(a))
print(type(b))
print(type(c))

#float
r=1.233
s=2.344
t=-34.33

print(type(r))
print(type(s))
print(type(t))

#complex numbers
x=6+10j
y=10j
z=-2j

print(type(x))
print(type(y))
print(type(z))

#TYPE OF CONVERSION
m=10#int
n=15#float
o=5j#complex

#convert from int to complex
l=complex(m)
print(l)
print(type(l))

#CONVERT FROM INT TO FLOAT
k=float(m)
print(k)
print(type(k))

#convert from float to complex
j=complex(n)
print(j)
print(type(j))


