print("Afternoon")
print('Afternoon')

#assign a string to  a variable
w = "Afternoon"
print(w)

#multiple strings

q="""I am student at makerere who has alot of stuff to do all the time of the day"""
print(q)

#strings as arrays
a="Afternoon"
print(a[0])

#EXERCISE 
#Use len() function to determine the length of a string
f="Mboowa"
print(len(f))

#EXERCISE 2
#For loop in a string
g="Mboowa"
for i in g:
    print(i)


 #EXERCISE 3
 #Use slicing in a string
    h="Mboowa"
    print(h[:])
    print(h[::2])
    print(h[::-1])
    print(h[0:3])
    print(h[:3])
    print(h[3:])
    print(h[::-2])


    #HOW TO MODIFY A STRING
    a="afternoon"
    print(a.lower())
    print(a.upper())

    #remove white space
    a="after noon"
    print(a.strip())

#string concatenation
    a="afternoon"
    b="morning"
    c=a+b
    print(c)

    z=a+" "+b
    print(z)

#exercises are in the middle 


