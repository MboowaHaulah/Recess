# Booleans These evaluate either a true or false

print(20<10)
print(30==40)
print(30>10)

print(bool(15))

r="Haulah"
z=20
print(bool(r))
print(bool(z))

#EXERCISE ONE 
#Use a condition to show how to use boolean
a = 200
b = 33

if b > a:
  print("true")
else:
  print("false")


