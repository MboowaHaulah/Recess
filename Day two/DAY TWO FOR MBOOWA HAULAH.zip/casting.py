#casting works mostly when u want to specify a variable type

h=int(20)
y=int(200000000)
a=int("8")
print(h)
print(y)
print(a)
print(type(a))