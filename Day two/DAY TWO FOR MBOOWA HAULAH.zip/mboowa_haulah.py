print("Hello, World!")

#VARIABLES
name="Haulah"

print(name)

age=2

print(age)

print(age,name)

#second example
x = 6
y = "Mboowa"
print(x)
print(y)

#DATA STRUCTURES/DATATYPES
#numeric,booleans,integers

#Sequence types- lists[] , tuples() , range-in loops, mapping types{}, set types,none types

gen_gender_sex=True
print(gen_gender_sex)


