#works when you want to combine strings and numbers
#format function takes in the passed arguments ,formats them and places them in the string 
#where the placeholders {} are

#Example one
age=23
#name="my name is Haulah, I am " +age
name = "my name is Haulah and I am {}"

print(name.format(age))

#Example two
quantity = 3
itemno = 567
price = 49.95
myorder = "I want {1} pieces of item {0} for {2} dollars."
print(myorder.format(quantity, itemno, price))

#PREVIEW
quantity = 3
itemno = 567
price = 49.95
myorder = "I want {} pieces of item {} for {} dollars."
print(myorder.format(quantity, itemno, price))
